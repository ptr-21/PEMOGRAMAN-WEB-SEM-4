document.addEventListener("DOMContentLoaded", function () {
  var h1Element = document.getElementById("myH1");
  h1Element.textContent = "Hello, World!";
});
