  document.addEventListener("DOMContentLoaded", function () {
    console.log("Script my_code_2.js loaded!");
  });
