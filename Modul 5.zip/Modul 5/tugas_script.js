let runningTotal = 0;
let buffer = "0";
let operation = "";
let previousOperator;
const result = document.querySelector(".result");
function buttonClick(value) {
    if (isNaN(value)) {
        handleSymbol(value);
    } else {
        handleNumber(value);
    }
    result.innerText = buffer;
}
function buttonClick(value) {
    if (isNaN(value)) {
        handleSymbol(value);
    } else {
        handleNumber(value);
    }
    result.innerText = operation;
}
function handleSymbol(symbol) {
    switch (symbol) {
        case 'AC':
            buffer = "0";
            runningTotal = 0;
            operation = "";
            result.innerText = buffer;
            break;
        case '=':
            if (previousOperator === null) {
                return;
            }
            flushOperation(parseFloat(buffer));
            previousOperator = null;
            buffer = "" + runningTotal;
            operation = buffer;
            runningTotal = 0;
            break;
        case '←':
            if (operation.slice(-1) === ' ') {
                operation = operation.slice(0, -3);
                buffer = operation.slice(-1);
            } else {
                operation = operation.slice(0, -1);
                buffer = operation.slice(-1);
            }
            result.innerText = operation;
            break;
            case '+/-':
                if (buffer !== '0') {
                    buffer = buffer.startsWith('-') ? buffer.slice(1) : '-' + buffer;
                    operation = operation.slice(0, -buffer.length) + buffer;
                    if (runningTotal !== 0) {
                        runningTotal *= -1;
                    }
                }
            break;
        case '.':
            if (!buffer.includes('.')) {
                buffer += '.';
                operation += '.';
            }
            break;
        case '%':
            if (buffer !== '0') {
                if (runningTotal !== 0) {
                    buffer = String(runningTotal * parseFloat(buffer) / 100);
                } else {
                    buffer = String(parseFloat(buffer) / 100);
                }
                operation = operation.slice(0, -buffer.length) + buffer;
            }
            break;
        case '+':
        case '−':
        case '×':
        case '÷':
            handleMath(symbol);
            break;
    }
    result.innerText = operation;
}
function handleMath(symbol) {
    if (buffer === '0') {
        return;
    }
    const floatBuffer = parseFloat(buffer);
    if (runningTotal === 0) {
        runningTotal = floatBuffer;
    } else {
        flushOperation(floatBuffer);
    }
    previousOperator = symbol;
    buffer = '0';
    operation += " " + symbol + " ";
}
function flushOperation(floatBuffer) {
    if (previousOperator === '+') {
        runningTotal += floatBuffer;
    } else if (previousOperator === '−') {
        runningTotal -= floatBuffer;
    } else if (previousOperator === '×') {
        runningTotal *= floatBuffer;
    } else if (previousOperator === '÷') {
        runningTotal /= floatBuffer;
    }
}
function handleNumber(numberString) {
    if (buffer === "0" && numberString !== ".") {
        buffer = numberString;
    } else {
        buffer += numberString;
    }
    operation += numberString;

}
function init() {
    document.querySelector('.button').addEventListener('click', function (event) {
        buttonClick(event.target.innerText);
    })
}
init();